globalThis.__KRISTOU_SUPABASE_URL__ = '';
globalThis.__KRISTOU_SUPABASE_PUBLISHABLE_KEY__ = '';

import test from 'node:test';
import assert from 'node:assert';

const { loadMyPreferences, updateUserPreferences } = await import('../src/lib/domains/preferences.ts');
const { sendParentNote, validateParentNoteSubmission } = await import('../src/lib/domains/parentNotes.ts');

function createMockSupabaseClient({
  preferenceData = null,
  preferenceError = null,
  rpcData = null,
  rpcError = null,
} = {}) {
  let capturedQuery = null;
  return {
    from(table) {
      assert.strictEqual(table, 'user_preferences');
      return {
        select(cols) {
          capturedQuery = { select: cols };
          return {
            eq(col, val) {
              capturedQuery.eq = { col, val };
              return {
                async maybeSingle() {
                  if (preferenceError) return { data: null, error: preferenceError };
                  return { data: preferenceData, error: null };
                }
              };
            }
          };
        }
      };
    },
    async rpc(fnName, args) {
      capturedQuery = { rpc: fnName, args };
      if (rpcError) return { data: null, error: rpcError };
      return { data: rpcData, error: null };
    },
    getCaptured() {
      return capturedQuery;
    }
  };
}

test('1. loadMyPreferences rejects missing or empty user ID', async () => {
  const client = createMockSupabaseClient();
  const resMissing = await loadMyPreferences('', client);
  assert.strictEqual(resMissing.ok, false);
  assert.strictEqual(resMissing.errorCode, 'invalid_user_id');

  const resWhitespace = await loadMyPreferences('   ', client);
  assert.strictEqual(resWhitespace.ok, false);
  assert.strictEqual(resWhitespace.errorCode, 'invalid_user_id');
});

test('2. loadMyPreferences applies user_id filter and returns data: null when missing', async () => {
  const client = createMockSupabaseClient({ preferenceData: null });
  const res = await loadMyPreferences('user-123', client);
  assert.strictEqual(res.ok, true);
  assert.strictEqual(res.status, 'READY');
  assert.strictEqual(res.data, null);

  const captured = client.getCaptured();
  assert.deepStrictEqual(captured.eq, { col: 'user_id', val: 'user-123' });
});

test('3. loadMyPreferences maps returned row correctly when record exists', async () => {
  const row = {
    language: 'ar',
    theme: 'pitch-black',
    notification_sound: 'Soft Chime',
    sound_muted: true,
    vibration_enabled: false,
  };
  const client = createMockSupabaseClient({ preferenceData: row });
  const res = await loadMyPreferences('user-456', client);
  assert.strictEqual(res.ok, true);
  assert.strictEqual(res.data.language, 'ar');
  assert.strictEqual(res.data.theme, 'pitch-black');
  assert.strictEqual(res.data.notificationSound, 'Soft Chime');
  assert.strictEqual(res.data.soundMuted, true);
  assert.strictEqual(res.data.vibrationEnabled, false);
});

test('4. updateUserPreferences uses exact server RPC response data (submitting fr, server returns en)', async () => {
  const updatedRow = {
    language: 'en',
    theme: 'pitch-black',
    notification_sound: 'Soft Chime',
    sound_muted: true,
    vibration_enabled: false,
  };
  const client = createMockSupabaseClient({ rpcData: updatedRow });
  const res = await updateUserPreferences({ language: 'fr' }, client);
  assert.strictEqual(res.ok, true);
  assert.strictEqual(res.data.language, 'en'); // Proves server response is used instead of echoing input 'fr'
});

test('5. sendParentNote respects positional signature (client, now) and nested note mapping', async () => {
  const mockNote = {
    id: 'note-1',
    parent_user_id: 'parent-1',
    parent_name: 'Parent Name',
    student_id: 'student-1',
    student_name: 'Student Name',
    topic: 'ABSENCE',
    content: 'My child is absent today.',
    created_at: new Date().toISOString(),
    status: 'SENT',
  };
  const client = {
    async rpc(fnName, args) {
      assert.strictEqual(fnName, 'send_parent_note');
      return {
        data: {
          note: mockNote,
          remainingToday: 7,
        },
        error: null,
      };
    }
  };

  const fixedNow = new Date('2026-11-19T10:00:00Z'); // 10:00 AM UTC (within Tunis window)
  const res = await sendParentNote('student-1', 'ABSENCE', 'My child is absent today.', client, fixedNow);
  assert.strictEqual(res.ok, true);
  assert.strictEqual(res.data.remainingToday, 7);
  assert.strictEqual(res.data.note.id, 'note-1');
});

test('6. sendParentNote rejects malformed RPC response missing note object', async () => {
  const client = {
    async rpc() {
      return { data: { remainingToday: 5 }, error: null }; // missing note object
    }
  };
  const fixedNow = new Date('2026-11-19T10:00:00Z');
  const res = await sendParentNote('student-1', 'ABSENCE', 'Test', client, fixedNow);
  assert.strictEqual(res.ok, false);
  assert.strictEqual(res.errorCode, 'invalid_rpc_response');
});

test('7. validateParentNoteSubmission enforces Tunis-time window boundaries', () => {
  // 07:59 Tunis time (06:59 UTC in winter) -> outside window
  const tooEarly = new Date('2026-11-19T06:59:00Z');
  assert.deepStrictEqual(validateParentNoteSubmission('Test', tooEarly), { valid: false, errorCode: 'parent_notes_outside_window' });

  // 08:00 Tunis time (07:00 UTC in winter) -> inside window
  const startWindow = new Date('2026-11-19T07:00:00Z');
  assert.deepStrictEqual(validateParentNoteSubmission('Test', startWindow), { valid: true });

  // 17:59 Tunis time (16:59 UTC) -> inside window
  const endWindow = new Date('2026-11-19T16:59:00Z');
  assert.deepStrictEqual(validateParentNoteSubmission('Test', endWindow), { valid: true });

  // 18:00 Tunis time (17:00 UTC) -> outside window
  const tooLate = new Date('2026-11-19T17:00:00Z');
  assert.deepStrictEqual(validateParentNoteSubmission('Test', tooLate), { valid: false, errorCode: 'parent_notes_outside_window' });
});
