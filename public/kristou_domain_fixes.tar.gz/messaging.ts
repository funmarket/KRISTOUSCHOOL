import { supabase, classifySupabaseError } from '../supabase.ts';
import type { AccountRole, MessageThread, MessageRecipientOption, BackendOpResult } from '../../types.ts';

export const SHORT_MESSAGE_MAX_CHARS = 200;

function unavailableResult<T>(): BackendOpResult<T> {
  return {
    ok: false,
    status: 'BLOCKED_BACKEND',
    errorCode: 'backend_unavailable',
    errorMessage: 'This workflow is awaiting verified Supabase backend deployment.',
  };
}

export function countUnreadThreads(
  threads: readonly MessageThread[] | null | undefined,
  status?: string,
): number {
  if (status !== 'READY' || !Array.isArray(threads)) return 0;
  return threads.filter((thread) => Boolean(thread.unread)).length;
}

export function validateShortMessageContent(
  content: string,
): { valid: true; clean: string } | { valid: false; errorCode: string } {
  const clean = content.trim();
  if (clean.length < 1 || clean.length > SHORT_MESSAGE_MAX_CHARS) {
    return { valid: false, errorCode: 'message_length_invalid' };
  }
  return { valid: true, clean };
}

export function canParticipantMessage(
  senderRole: AccountRole | null | undefined,
  recipientRole: AccountRole | null | undefined,
): boolean {
  if (!senderRole || !recipientRole) return false;
  if (senderRole === 'STUDENT' || recipientRole === 'STUDENT') return false;
  if (senderRole === 'PARENT' && (recipientRole === 'PARENT' || recipientRole === 'SCHOOL_STAFF')) {
    return false;
  }
  if (recipientRole === 'PARENT' && (senderRole === 'PARENT' || senderRole === 'SCHOOL_STAFF')) {
    return false;
  }
  return true;
}

export async function listMessageThreads(
  userId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<MessageThread[]>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data: threadRows, error: threadErr } = await activeClient
      .from('message_threads')
      .select('*')
      .order('updated_at', { ascending: false });
    if (threadErr) return { ok: false, ...classifySupabaseError(threadErr) };

    const threads = Array.isArray(threadRows) ? threadRows : [];
    const threadIds = threads.map((t: Record<string, unknown>) => String(t.id));

    if (threadIds.length === 0) {
      return { ok: true, status: 'READY', data: [] };
    }

    const [partRes, msgRes] = await Promise.all([
      activeClient.from('thread_participants').select('*').in('thread_id', threadIds),
      activeClient.from('thread_messages').select('*').in('thread_id', threadIds).order('created_at', { ascending: true }),
    ]);

    if (partRes.error) return { ok: false, ...classifySupabaseError(partRes.error) };
    if (msgRes.error) return { ok: false, ...classifySupabaseError(msgRes.error) };

    const participantsByThread = new Map<string, any[]>();
    for (const p of (partRes.data || []) as Record<string, unknown>[]) {
      const tid = String(p.thread_id);
      const list = participantsByThread.get(tid) ?? [];
      list.push(p);
      participantsByThread.set(tid, list);
    }

    const messagesByThread = new Map<string, any[]>();
    for (const m of (msgRes.data || []) as Record<string, unknown>[]) {
      const tid = String(m.thread_id);
      const list = messagesByThread.get(tid) ?? [];
      list.push({
        id: String(m.id),
        senderId: String(m.sender_user_id || ''),
        senderName: String(m.sender_name || 'Member'),
        content: String(m.content || ''),
        createdAt: String(m.created_at || new Date().toISOString()),
      });
      messagesByThread.set(tid, list);
    }

    // Profiles map for recipient names/roles lookup if needed
    const mappedThreads: MessageThread[] = threads.map((t: Record<string, unknown>) => {
      const tid = String(t.id);
      const parts = participantsByThread.get(tid) ?? [];
      const msgs = messagesByThread.get(tid) ?? [];
      const myPart = parts.find((p) => String(p.user_id) === String(userId));
      const otherPart = parts.find((p) => String(p.user_id) !== String(userId)) || parts[0];
      const lastMsg = msgs[msgs.length - 1];

      return {
        id: tid,
        threadId: tid,
        subject: t.subject ? String(t.subject) : undefined,
        recipientId: otherPart ? String(otherPart.user_id) : '',
        recipientName: otherPart ? String(otherPart.full_name || otherPart.username || 'Member') : 'Member',
        recipientRole: otherPart ? String(otherPart.role || 'STAFF') : 'STAFF',
        lastMessage: lastMsg ? lastMsg.content : String(t.last_message_preview || ''),
        updatedAt: String(t.updated_at || new Date().toISOString()),
        unread: Boolean(myPart?.unread),
        messages: msgs,
      };
    });

    return { ok: true, status: 'READY', data: mappedThreads };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function listApprovedMessageRecipients(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<MessageRecipientOption[]>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('list_approved_message_recipients');
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const items = Array.isArray(data)
      ? data.map((r: Record<string, unknown>) => ({
          id: String(r.id),
          fullName: String(r.full_name || r.fullName || ''),
          role: (String(r.role || 'STAFF') as AccountRole),
        }))
      : [];
    return { ok: true, status: 'READY', data: items };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function sendOperationalMessage(
  recipientUserId: string,
  subject: string,
  content: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<{ threadId: string }>> {
  const activeClient = client || supabase;
  const check = validateShortMessageContent(content);
  if (!check.valid) {
    return { ok: false, status: 'ERROR', errorCode: check.errorCode, errorMessage: 'Message content length invalid.' };
  }
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('send_operational_message', {
      p_recipient_user_id: recipientUserId,
      p_subject: subject.trim(),
      p_content: check.clean,
    });
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const r = (data ?? {}) as Record<string, unknown>;
    const tid = String(r.id || r.thread_id || '');
    return {
      ok: true,
      status: 'READY',
      data: { threadId: tid },
    };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function replyOperationalThread(
  threadId: string,
  content: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<{ id: string }>> {
  const activeClient = client || supabase;
  const check = validateShortMessageContent(content);
  if (!check.valid) {
    return { ok: false, status: 'ERROR', errorCode: check.errorCode, errorMessage: 'Reply content length invalid.' };
  }
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('reply_operational_thread', {
      p_thread_id: threadId,
      p_content: check.clean,
    });
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const r = (data ?? {}) as Record<string, unknown>;
    return {
      ok: true,
      status: 'READY',
      data: { id: String(r.id || '') },
    };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}
