import { supabase, classifySupabaseError } from '../supabase.ts';
import type { BackendOpResult, UserPreferencesState } from '../../types.ts';

function unavailableResult<T>(): BackendOpResult<T> {
  return {
    ok: false,
    status: 'BLOCKED_BACKEND',
    errorCode: 'backend_unavailable',
    errorMessage: 'This workflow is awaiting verified Supabase backend deployment.',
  };
}

export async function fetchUserPreferences(
  userId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<UserPreferencesState | null>> {
  return loadMyPreferences(userId, client);
}

export async function loadMyPreferences(
  userId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<UserPreferencesState | null>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  if (!userId || typeof userId !== 'string' || userId.trim().length === 0) {
    return { ok: false, status: 'ERROR', errorCode: 'invalid_user_id', errorMessage: 'User ID is required for preferences load.' };
  }
  try {
    const { data, error } = await activeClient
      .from('user_preferences')
      .select('language, theme, notification_sound, sound_muted, vibration_enabled')
      .eq('user_id', userId.trim())
      .maybeSingle();

    if (error) return { ok: false, ...classifySupabaseError(error) };
    if (!data) {
      return { ok: true, status: 'READY', data: null };
    }
    const row = data as Record<string, unknown>;
    return {
      ok: true,
      status: 'READY',
      data: {
        language: (String(row.language || 'fr') as UserPreferencesState['language']),
        theme: (String(row.theme || 'light') as UserPreferencesState['theme']),
        notificationSound: (String(row.notification_sound || 'Kristou Bell') as UserPreferencesState['notificationSound']),
        soundMuted: Boolean(row.sound_muted),
        vibrationEnabled: row.vibration_enabled !== false,
      },
    };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function updateUserPreferences(
  preferences: Partial<UserPreferencesState>,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<UserPreferencesState>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('upsert_my_preferences', {
      p_language: preferences.language ?? null,
      p_theme: preferences.theme ?? null,
      p_notification_sound: preferences.notificationSound ?? null,
      p_sound_muted: preferences.soundMuted ?? null,
      p_vibration_enabled: preferences.vibrationEnabled ?? null,
    });
    if (error) return { ok: false, ...classifySupabaseError(error) };

    if (!data) {
      return { ok: false, status: 'ERROR', errorCode: 'invalid_rpc_response', errorMessage: 'Server returned empty preferences response.' };
    }

    const row = data as Record<string, unknown>;
    return {
      ok: true,
      status: 'READY',
      data: {
        language: (String(row.language || 'fr') as UserPreferencesState['language']),
        theme: (String(row.theme || 'light') as UserPreferencesState['theme']),
        notificationSound: (String(row.notification_sound || 'Kristou Bell') as UserPreferencesState['notificationSound']),
        soundMuted: Boolean(row.sound_muted),
        vibrationEnabled: row.vibration_enabled !== false,
      },
    };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function saveMyPreferences(
  preferences: Partial<UserPreferencesState>,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<UserPreferencesState>> {
  return updateUserPreferences(preferences, client);
}
