import { supabase, classifySupabaseError } from '../supabase.ts';
import type { BackendOpResult, FoodMenuWeek, FoodMenuItem } from '../../types.ts';

function unavailableResult<T>(): BackendOpResult<T> {
  return {
    ok: false,
    status: 'BLOCKED_BACKEND',
    errorCode: 'backend_unavailable',
    errorMessage: 'This workflow is awaiting verified Supabase backend deployment.',
  };
}

export async function listFoodMenus(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<FoodMenuWeek[]>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data: weekRows, error: weekErr } = await activeClient
      .from('food_menu_weeks')
      .select('id, week_range, status, provider_name, created_at')
      .order('created_at', { ascending: false });
    if (weekErr) return { ok: false, ...classifySupabaseError(weekErr) };

    const weeks = Array.isArray(weekRows) ? weekRows : [];
    const weekIds = weeks.map((w: Record<string, unknown>) => String(w.id));
    const daysMap = new Map<string, any[]>();

    if (weekIds.length > 0) {
      const { data: dayRows, error: dayErr } = await activeClient
        .from('food_menu_days')
        .select('*')
        .in('menu_week_id', weekIds)
        .order('day_order', { ascending: true });
      if (!dayErr && Array.isArray(dayRows)) {
        for (const d of dayRows as Record<string, unknown>[]) {
          const wid = String(d.menu_week_id);
          const list = daysMap.get(wid) ?? [];
          list.push({
            day: String(d.day_label || `Day ${d.day_order}`),
            starter: String(d.starter || ''),
            main: String(d.main_dish || ''),
            side: String(d.side_dish || ''),
            dessert: String(d.dessert || ''),
            notes: d.notes ? String(d.notes) : undefined,
          });
          daysMap.set(wid, list);
        }
      }
    }

    const mapped: FoodMenuWeek[] = weeks.map((w: Record<string, unknown>) => {
      const wid = String(w.id);
      const st = String(w.status || 'PUBLISHED');
      return {
        id: wid,
        weekRange: String(w.week_range || ''),
        published: st === 'PUBLISHED',
        status: (st as FoodMenuWeek['status']),
        providerName: String(w.provider_name || 'La Toque Gourmande'),
        isDemoPreview: st === 'PUBLISHED',
        items: daysMap.get(wid) ?? [],
      };
    });

    return { ok: true, status: 'READY', data: mapped };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function fetchActiveFoodMenu(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<FoodMenuWeek | null>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error: weekErr } = await activeClient
      .from('food_menu_weeks')
      .select('id, week_range, status, provider_name, created_at')
      .eq('status', 'PUBLISHED')
      .order('created_at', { ascending: false })
      .limit(1);

    if (weekErr) return { ok: false, ...classifySupabaseError(weekErr) };
    const weekRow = Array.isArray(data) && data.length > 0 ? data[0] : null;
    if (!weekRow) return { ok: true, status: 'READY', data: null };

    const wid = String(weekRow.id);
    const { data: dayRows, error: dayErr } = await activeClient
      .from('food_menu_days')
      .select('*')
      .eq('menu_week_id', wid)
      .order('day_order', { ascending: true });

    if (dayErr) return { ok: false, ...classifySupabaseError(dayErr) };

    const items = Array.isArray(dayRows)
      ? dayRows.map((d: Record<string, unknown>) => ({
          day: String(d.day_label || `Day ${d.day_order}`),
          starter: String(d.starter || ''),
          main: String(d.main_dish || ''),
          side: String(d.side_dish || ''),
          dessert: String(d.dessert || ''),
          notes: d.notes ? String(d.notes) : undefined,
        }))
      : [];

    const activeMenu: FoodMenuWeek = {
      id: wid,
      weekRange: String(weekRow.week_range || ''),
      published: true,
      status: 'PUBLISHED',
      providerName: String(weekRow.provider_name || 'La Toque Gourmande'),
      isDemoPreview: true,
      items,
    };

    return { ok: true, status: 'READY', data: activeMenu };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function saveFoodMenuWeek(
  weekRange: string,
  days: FoodMenuItem[],
  publish = true,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<{ id: string }>> {
  const activeClient = client || supabase;
  const rangeStr = typeof weekRange === 'string' ? weekRange.trim() : '';
  const dayList = Array.isArray(days) ? days : [];

  if (rangeStr.length < 3 || dayList.length === 0) {
    return {
      ok: false,
      status: 'ERROR',
      errorCode: 'invalid_menu_input',
      errorMessage: 'Valid week range (at least 3 characters) and at least one menu day are required.',
    };
  }

  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('save_food_menu_week', {
      p_week_range: rangeStr,
      p_days: dayList,
      p_publish: publish,
    });
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const r = (data ?? {}) as Record<string, unknown>;
    return {
      ok: true,
      status: 'READY',
      data: { id: String(r.id || '') },
    };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}
