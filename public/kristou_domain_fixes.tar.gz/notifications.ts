import { supabase, classifySupabaseError } from '../supabase.ts';
import type { BackendOpResult, NotificationItem } from '../../types.ts';

function unavailableResult<T>(): BackendOpResult<T> {
  return {
    ok: false,
    status: 'BLOCKED_BACKEND',
    errorCode: 'backend_unavailable',
    errorMessage: 'This workflow is awaiting verified Supabase backend deployment.',
  };
}

export async function listNotifications(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<NotificationItem[]>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient
      .from('user_notifications')
      .select('id, category, title, body, target_tab, target_ref_id, is_read, created_at')
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const mapped: NotificationItem[] = Array.isArray(data)
      ? data.map((row: Record<string, unknown>) => ({
          id: String(row.id),
          title: String(row.title || ''),
          message: String(row.body || ''),
          time: String(row.created_at || new Date().toISOString()),
          read: Boolean(row.is_read),
          type: (String(row.category || 'announcement') as NotificationItem['type']),
          targetTab: row.target_tab ? String(row.target_tab) : undefined,
          targetRefId: row.target_ref_id ? String(row.target_ref_id) : undefined,
        }))
      : [];
    return { ok: true, status: 'READY', data: mapped };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function listMyNotifications(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<NotificationItem[]>> {
  return listNotifications(client);
}

export async function markNotificationReadOnServer(
  notificationId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<boolean>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('mark_user_notification_read', {
      p_notification_id: notificationId,
    });
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const success = Boolean(data);
    return { ok: true, status: 'READY', data: success };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}

export async function markAllNotificationsReadOnServer(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  client: any = supabase,
): Promise<BackendOpResult<number>> {
  const activeClient = client || supabase;
  if (!activeClient) return unavailableResult();
  try {
    const { data, error } = await activeClient.rpc('mark_all_user_notifications_read');
    if (error) return { ok: false, ...classifySupabaseError(error) };
    const count = typeof data === 'number' ? data : (data && typeof data === 'object' ? Number((data as any).count ?? 0) : 0);
    return { ok: true, status: 'READY', data: count };
  } catch (err) {
    return { ok: false, ...classifySupabaseError(err) };
  }
}
